import controller.LigaController;
import model.Entrenador;

public class entrada {
    public static void main(String[] args) {
        LigaController ligaController = new LigaController(); // Con esto tengo acceso a todos los elementos

        ligaController.agregarEntrenador(new Entrenador("nicolas",9,0));

        ligaController.obtenerEntrenador(1);
    }
}

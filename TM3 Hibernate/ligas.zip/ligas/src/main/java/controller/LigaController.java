package controller;

import dao.EntrenadorDao;
import dao.EquipoDao;
import model.Entrenador;
import model.Equipo;

// Gestiona todo lo que haya en la liga
public class LigaController {

    private EntrenadorDao entrenadorDao;
    private EquipoDao equipoDao;

    public LigaController() {
        entrenadorDao = new EntrenadorDao();
        equipoDao = new EquipoDao();
    }

    public void agregarEntrenador(Entrenador entrenador) {


        //aplica la logica del negocio
        //hacemos preguntas para validar un entrenador.
        // si esta todo como necesito, persiste
        // Sino o  da fallo, no se incluye, no vale en el equipo
        // Se hace el filtro hacia la base de datos.


        if( entrenador.getCalificacion()<10){
            System.out.println("No es valido para este equipo");
        }else{
            entrenadorDao.agregarEntrenador(entrenador);
        }



    }
public void obtenerEntrenador(int id){

        Entrenador entrenador = entrenadorDao.obtenerEntrenador(id);

    System.out.println(entrenador.getNombre());

        if(entrenador.getTitulos()>4){
            Equipo equipo = equipoDao.getEquipo(1)// Lo añado
            equipo.setEntrenador(entrenador);
            equipoDao.actualizarEquipo(equipo);
        }else{
            // Hago otra cosa
        }
}
}

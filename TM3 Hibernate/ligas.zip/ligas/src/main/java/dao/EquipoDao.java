package dao;

import com.mysql.cj.Session;
import database.HibernateUtil;
import model.Equipo;

public class EquipoDao {
    Session session;

    public Equipo getEquipo(int id){
        session = new HibernateUtil().getSessionFactory().getCurrentSession(); // 1-Abro
        session.beginTransaction(); // 2- INICIO

        Equipo equipo = session.get(Equipo.class, id);

        sesion.persist(getEquipo());

        session.getTransaction().commit(); // 3- Garantizo, Confirmo
        session.close(); // 4- Cierro
        return equipo;
    }

    public void actualizarEquipo(Equipo equipo){
        session= new HibernateUtil().getSessionFactory().getCurrentSession();
        session.beginTransaction();
        session.merge(equipo);
        session.getTransaction().commit();
        session.close();
    }


}




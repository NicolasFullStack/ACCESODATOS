package dao;

import org.hibernate.Session;
import database.HibernateUtil;
import model.Liga;

public class LigasDao {

    Session session;

    // persist -- guarda
    // merge -- actualiza--inserta (id)
    // list  -- select (id)
    // delete -- (id)


    public void crearLiga(Liga liga){

        session = new HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction().begin();
        session.getTransaction().commit();
        session.close();


    }


}
